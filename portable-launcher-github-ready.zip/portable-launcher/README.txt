PORTABLE LAUNCHER

Android native launcher prototype: landscape, touchscreen-friendly, PSP-inspired portable layout, water/sky visual, animated background, and controller support.

Controls:
D-pad left/right or L1/R1/L2/R2 = navigate
A/Enter = select
B/Back = back

Build: GitHub Actions workflow in .github/workflows/build-apk.yml
