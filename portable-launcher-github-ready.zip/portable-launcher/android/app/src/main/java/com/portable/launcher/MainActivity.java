package com.portable.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.content.Context;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LauncherView view;
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN); view=new LauncherView(this); setContentView(view); }
    @Override public boolean dispatchKeyEvent(KeyEvent e){ if(e.getAction()==KeyEvent.ACTION_DOWN){ if(view.handleKey(e.getKeyCode())) return true; } return super.dispatchKeyEvent(e); }

    class LauncherView extends View {
        Paint p=new Paint(3); int selected=0; String[] apps={"JOGOS","APPS","FAVORITOS","CONFIGURAÇÕES"}; float t=0;
        LauncherView(Context c){ super(c); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); setFocusable(true); }
        protected void onDraw(Canvas c){ super.onDraw(c); int w=getWidth(),h=getHeight();
            LinearGradient sky=new LinearGradient(0,0,0,h,Color.rgb(112,207,239),Color.rgb(224,249,255),Shader.TileMode.CLAMP); p.setShader(sky); c.drawRect(0,0,w,h,p); p.setShader(null);
            // water
            p.setColor(Color.argb(90,255,255,255)); for(int y=h/2;y<h;y+=38){ c.drawOval(-80,y,w+80,y+22,p); }
            // clouds
            p.setColor(Color.argb(180,255,255,255)); cloud(c,w*.12f,h*.16f,1.0f); cloud(c,w*.78f,h*.11f,.8f);
            p.setColor(Color.rgb(255,255,255)); p.setTextSize(42); c.drawText("PORTABLE",36,58,p); p.setTextSize(18); c.drawText("LAUNCHER",39,83,p);
            float cardW=Math.min(330,w*.22f), cardH=Math.min(190,h*.46f), gap=24, total=apps.length*cardW+3*gap, x=(w-total)/2f, y=h*.31f;
            for(int i=0;i<apps.length;i++){ drawCard(c,x+i*(cardW+gap),y,cardW,cardH,apps[i],i==selected); }
            p.setTextSize(18); p.setColor(Color.argb(220,20,90,115)); c.drawText("◀ ▶  navegar    A  selecionar    B  voltar",w/2f-190,h-25,p);
            invalidate();
        }
        void cloud(Canvas c,float x,float y,float s){ p.setColor(Color.argb(170,255,255,255)); c.drawOval(x-80*s,y,x+40*s,y+45*s,p); c.drawOval(x-35*s,y-20*s,x+75*s,y+55*s,p); c.drawOval(x+25*s,y,x+120*s,y+48*s,p); }
        void drawCard(Canvas c,float x,float y,float w,float h,String text,boolean sel){
            GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.argb(sel?245:190,255,255,255),Color.argb(sel?220:160,160,230,245)}); g.setCornerRadius(32); g.setStroke(sel?6:2,Color.argb(sel?230:120,255,255,255)); g.setBounds((int)x,(int)y,(int)(x+w),(int)(y+h)); g.draw(c);
            p.setColor(Color.argb(55,0,90,130)); c.drawCircle(x+w/2,y+h*.38f,42,p); p.setColor(Color.WHITE); p.setTextSize(19); p.setTextAlign(Paint.Align.CENTER); c.drawText(text,x+w/2,y+h*.78f,p); p.setTextAlign(Paint.Align.LEFT);
        }
        boolean handleKey(int k){
            if(k==KeyEvent.KEYCODE_DPAD_RIGHT || k==KeyEvent.KEYCODE_BUTTON_R1 || k==KeyEvent.KEYCODE_BUTTON_R2){selected=(selected+1)%apps.length; return true;}
            if(k==KeyEvent.KEYCODE_DPAD_LEFT || k==KeyEvent.KEYCODE_BUTTON_L1 || k==KeyEvent.KEYCODE_BUTTON_L2){selected=(selected+apps.length-1)%apps.length; return true;}
            if(k==KeyEvent.KEYCODE_BUTTON_A || k==KeyEvent.KEYCODE_ENTER){ Toast.makeText(MainActivity.this,"Selecionado: "+apps[selected],Toast.LENGTH_SHORT).show(); return true; }
            if(k==KeyEvent.KEYCODE_BUTTON_B || k==KeyEvent.KEYCODE_BACK){ Toast.makeText(MainActivity.this,"Voltar",Toast.LENGTH_SHORT).show(); return true; }
            return false;
        }
    }
}
